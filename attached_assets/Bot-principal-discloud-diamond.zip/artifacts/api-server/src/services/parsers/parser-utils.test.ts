import { describe, expect, it } from "vitest";
import { parsePlatformChapterHtml } from "./parser-utils.js";

describe("parser de cards do Toptoon", () => {
  it("usa a miniatura lazy do card e ignora o banner promocional da página", () => {
    const html = `
      <a class="episode-items" data-episode-id="2"
        data-ep_thumb1="https://smurfs.toptoon.com/ep_thumb1/episode-2.jpg"
        data-ep_thumb2="https://smurfs.toptoon.com/ep_thumb2/episode-2.jpg">
        <div class="ep_thumb lazy"
          data-bg="https://smurfs.toptoon.com/ep_thumb1/episode-2.jpg"></div>
        <p class="ep_title">제2화</p>
      </a>
      <img src="https://azrael.toptoon.com/assets/img/www/banner/eplist_bnr_app2_new.jpg"
        alt="FULLVERSION APP">
    `;

    expect(parsePlatformChapterHtml(
      html,
      "https://toptoon.com/comic/ep_list/TasteFolder",
      "toptoon",
    )).toEqual([
      {
        number: "2",
        thumbnailUrl: "https://smurfs.toptoon.com/ep_thumb1/episode-2.jpg",
      },
    ]);
  });
});