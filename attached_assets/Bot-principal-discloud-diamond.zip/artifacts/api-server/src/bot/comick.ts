import { fetchComick, parseComickJson } from "./comick-http.js";

const BASE = (process.env.COMICK_API_BASE ?? "https://api.comick.dev").replace(/\/+$/, "");
const COVER_BASE = "https://meo.comick.pictures";

interface ComickTitle {
  title?: string;
  lang?: string | null;
}

interface ComickCover {
  b2key?: string;
  vol?: string | null;
  w?: number;
  h?: number;
}

interface ComickGenre {
  name?: string;
}

export interface ComickResult {
  hid?: string;
  slug?: string;
  title?: string;
  md_titles?: ComickTitle[];
  status?: number | null;
  rating?: string | null;
  genres?: Array<ComickGenre | number>;
  country?: string | null;
  year?: number | null;
  md_covers?: ComickCover[];
  last_chapter?: number | null;
  desc?: string | null;
}

const STATUS_MAP: Record<number, string> = {
  1: "RELEASING",
  2: "FINISHED",
  3: "CANCELLED",
  4: "HIATUS",
};

const COUNTRY_MAP: Record<string, string> = {
  ko: "KR",
  cn: "CN",
  jp: "JP",
};

export function comickCoverUrl(result: ComickResult): string | null {
  const cover = result.md_covers?.[0];
  if (!cover?.b2key) return null;
  return `${COVER_BASE}/${cover.b2key}`;
}

export function comickStatus(status: number | null): string | null {
  return status !== null ? (STATUS_MAP[status] ?? null) : null;
}

export function comickCountry(country: string | null): string | null {
  return country ? (COUNTRY_MAP[country] ?? null) : null;
}

// ─── Helpers de comparação para recuperação de 404 ───────────────────────────

/** Normaliza uma string para comparação: remove acentos, minúsculas, só alfanumérico. */
function normalizeForComparison(value: string): string {
  return value
    .normalize("NFD")
    .replace(/\p{Diacritic}/gu, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "");
}

/**
 * Converte um slug do Comick em uma query de busca legível.
 * Ex: "solo-leveling-2" → "solo leveling 2"
 */
function slugToQuery(slug: string): string {
  return slug.replace(/[-_]+/g, " ").trim();
}

/**
 * Pontua um candidato de busca contra o termo original.
 * Retorna um valor entre 0 e 4 (quanto maior, mais confiável).
 * 0 = sem correspondência utilizável.
 */
function scoreCandidate(candidate: ComickResult, originalSlug: string): number {
  const normSlug = normalizeForComparison(originalSlug);
  if (!normSlug) return 0;

  // Slug exato (renomeação não aconteceu, obra diferente estava na URL)
  if (candidate.slug && normalizeForComparison(candidate.slug) === normSlug) return 4;

  const allTitles: string[] = [];
  if (candidate.title) allTitles.push(candidate.title);
  for (const t of candidate.md_titles ?? []) {
    if (t.title) allTitles.push(t.title);
  }

  const normTitles = allTitles.map(normalizeForComparison).filter(Boolean);
  const normQuery = normalizeForComparison(slugToQuery(originalSlug));

  // Título principal ou alternativo exato (após normalização)
  if (normTitles.some((t) => t === normQuery)) return 3;

  // Slug do candidato contém o slug original (variação com sufixo de volume/revisão)
  if (
    candidate.slug &&
    normSlug.length >= 6 &&
    normalizeForComparison(candidate.slug).includes(normSlug)
  ) return 2;

  // Algum título contém a query normalizada como substring (mínimo 6 chars)
  if (
    normQuery.length >= 6 &&
    normTitles.some((t) => t.includes(normQuery) || normQuery.includes(t))
  ) return 1;

  return 0;
}

// ─── Fetch do detalhe de uma obra pelo slug (reutilizado internamente) ────────

async function fetchComicDetail(
  identifier: string,
): Promise<ComickResult | null> {
  const response = await fetchComick(
    `${BASE}/comic/${encodeURIComponent(identifier)}`,
  );
  if (response.status < 200 || response.status >= 300) return null;

  const json = parseComickJson<{
    comic?: ComickResult;
    genres?: ComickGenre[];
    md_covers?: ComickCover[];
  } | ComickResult>(response);

  // API retorna { comic: {...}, genres: [...], md_covers: [...] } no endpoint de detalhes
  const comic = (json as { comic?: ComickResult }).comic ?? (json as ComickResult);
  if (!comic?.hid) return null;

  // genres e md_covers ficam na raiz da resposta de detalhes, não dentro de comic
  const topGenres = (json as { genres?: ComickGenre[] }).genres;
  const topCovers = (json as { md_covers?: ComickCover[] }).md_covers;

  if (topGenres && topGenres.length > 0) comic.genres = topGenres;
  if (topCovers && topCovers.length > 0) comic.md_covers = topCovers;
  if (!comic.genres) comic.genres = [];

  return comic;
}

// ─── API pública ──────────────────────────────────────────────────────────────

export async function searchComick(query: string): Promise<ComickResult[]> {
  const params = new URLSearchParams({ q: query, limit: "8", country: "ko" });
  const response = await fetchComick(`${BASE}/v1.0/search?${params}`);
  if (response.status < 200 || response.status >= 300) {
    throw new Error(`Comick search error: ${response.status}`);
  }
  const json = parseComickJson<ComickResult[]>(response);
  return Array.isArray(json) ? json : [];
}

export async function searchComickAny(query: string): Promise<ComickResult[]> {
  const params = new URLSearchParams({ q: query, limit: "8" });
  const response = await fetchComick(`${BASE}/v1.0/search?${params}`);
  if (response.status < 200 || response.status >= 300) return [];
  const json = parseComickJson<ComickResult[]>(response);
  return Array.isArray(json) ? json : [];
}

export async function getComickBySlug(slug: string): Promise<ComickResult | null> {
  try {
    const response = await fetchComick(
      `${BASE}/comic/${encodeURIComponent(slug)}`,
    );

    // O endpoint de detalhes pode retornar 404 ou ser bloqueado pelo Cloudflare
    // (403), enquanto a busca continua disponível. Nesse caso, usa o candidato
    // retornado pela busca; ele já traz os campos necessários para o comando.
    if (response.status < 200 || response.status >= 300) {
      const query = slugToQuery(slug);
      const candidates = await searchComickAny(query);

      // Pontua cada candidato e escolhe o mais provável
      let bestScore = 0;
      let bestCandidate: ComickResult | null = null;
      for (const candidate of candidates) {
        const score = scoreCandidate(candidate, slug);
        if (score > bestScore) {
          bestScore = score;
          bestCandidate = candidate;
        }
      }

      // Exige pontuação mínima de 2 para evitar falsos positivos
      if (bestScore < 2 || !bestCandidate?.slug) return null;

      // Tenta enriquecer pelo detalhe, mas não perde o resultado se o endpoint
      // estiver bloqueado ou indisponível.
      return (await fetchComicDetail(bestCandidate.hid ?? bestCandidate.slug)) ?? bestCandidate;
    }

    const json = parseComickJson<{
      comic?: ComickResult;
      genres?: ComickGenre[];
      md_covers?: ComickCover[];
    } | ComickResult>(response);

    // API retorna { comic: {...}, genres: [...], md_covers: [...] } no endpoint de detalhes
    const comic = (json as { comic?: ComickResult }).comic ?? (json as ComickResult);
    if (!comic?.hid) return null;

    // genres e md_covers ficam na raiz da resposta de detalhes, não dentro de comic
    const topGenres = (json as { genres?: ComickGenre[] }).genres;
    const topCovers = (json as { md_covers?: ComickCover[] }).md_covers;

    if (topGenres && topGenres.length > 0) {
      comic.genres = topGenres;
    }
    if (topCovers && topCovers.length > 0) {
      comic.md_covers = topCovers;
    }
    // Garante que genres nunca seja undefined
    if (!comic.genres) comic.genres = [];

    return comic;
  } catch {
    return null;
  }
}
