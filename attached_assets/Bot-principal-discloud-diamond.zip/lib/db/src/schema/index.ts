export * from "./bot-config";
import { pgTable, text, serial, timestamp, real, json, unique } from "drizzle-orm/pg-core";
export * from "./errorLogs";
export * from "./subscriptions";
export * from "./release-preferences";
export * from "./malSnapshots";

// ─── Status de leitura ───────────────────────────────────────────────────────

export const STATUS_OPCOES = ["lendo", "concluido", "planejo", "pausado", "abandonado"] as const;
export type StatusLeitura = (typeof STATUS_OPCOES)[number];

export const STATUS_LABELS: Record<StatusLeitura, string> = {
  lendo: "📖 Lendo",
  concluido: "✅ Concluído",
  planejo: "🔖 Planejo Ler",
  pausado: "⏸️ Pausado",
  abandonado: "🗑️ Abandonado",
};

// ─── Tabela: favoritos ────────────────────────────────────────────────────────

export const favoritosTable = pgTable("favoritos", {
  id: serial("id").primaryKey(),
  discordUserId: text("discord_user_id").notNull(),
  manhwaId: text("manhwa_id").notNull(),
  source: text("source").notNull(),
  title: text("title").notNull(),
  coverUrl: text("cover_url"),
  siteUrl: text("site_url").notNull(),
  genres: text("genres").notNull().default(""),
  score: text("score"),
  addedAt: timestamp("added_at").notNull().defaultNow(),
});

export type Favorito = typeof favoritosTable.$inferSelect;
export type InsertFavorito = typeof favoritosTable.$inferInsert;

// ─── Tabela: notificacao_canais ───────────────────────────────────────────────

export const notificacaoCanaisTable = pgTable("notificacao_canais", {
  guildId: text("guild_id").primaryKey(),
  channelId: text("channel_id").notNull(),
  alterationChannelId: text("alteration_channel_id"),
  configuredAt: timestamp("configured_at").notNull().defaultNow(),
});

export type NotificacaoCanal = typeof notificacaoCanaisTable.$inferSelect;

// ─── Tabela: notificacao_eventos ──────────────────────────────────────────────
// Ledger idempotente: um evento de capítulo só pode ser reservado uma vez por
// canal, mesmo que o processo reinicie antes de atualizar o rastreador.
export const notificacaoEventosTable = pgTable("notificacao_eventos", {
  eventKey: text("event_key").primaryKey(),
  channelId: text("channel_id").notNull(),
  title: text("title").notNull(),
  chapter: real("chapter").notNull(),
  claimedAt: timestamp("claimed_at").notNull().defaultNow(),
  sentAt: timestamp("sent_at"),
});

export type NotificacaoEvento = typeof notificacaoEventosTable.$inferSelect;

// ─── Tabela: capitulos_rastreados ─────────────────────────────────────────────

export const capitulosRastreados = pgTable("capitulos_rastreados", {
  id: serial("id").primaryKey(),
  manhwaId: text("manhwa_id").notNull(),
  source: text("source").notNull(),
  title: text("title").notNull(),
  coverUrl: text("cover_url"),
  siteUrl: text("site_url").notNull(),
  lastChapters: real("last_chapters"),
  lastChecked: timestamp("last_checked").notNull().defaultNow(),
  lastNotifiedAt: timestamp("last_notified_at"),
  /** Capítulo observado no início do ciclo semanal atual. */
  weeklyStartChapters: real("weekly_start_chapters"),
  weeklyStartAt: timestamp("weekly_start_at"),
}, (t) => [unique("capitulos_rastreados_manhwa_id_key").on(t.manhwaId)]);

export type CapituloRastreado = typeof capitulosRastreados.$inferSelect;

// ─── Tabela: mal_historico_alteracoes ─────────────────────────────────────────
// Histórico limitado das alterações observadas na API do MyAnimeList/Jikan.

export const malHistoricoAlteracoesTable = pgTable("mal_historico_alteracoes", {
  id: serial("id").primaryKey(),
  malId: text("mal_id").notNull(),
  title: text("title").notNull(),
  synopsis: text("synopsis"),
  score: real("score"),
  status: text("status"),
  chapters: real("chapters"),
  changedFields: json("changed_fields").$type<string[]>().notNull().default([]),
  observedAt: timestamp("observed_at").notNull().defaultNow(),
});

export type MalHistoricoAlteracao = typeof malHistoricoAlteracoesTable.$inferSelect;

// ─── Tabela: lista_leitura ────────────────────────────────────────────────────

export const listaLeituraTable = pgTable("lista_leitura", {
  id: serial("id").primaryKey(),
  discordUserId: text("discord_user_id").notNull(),
  manhwaId: text("manhwa_id").notNull(),
  source: text("source").notNull(),
  title: text("title").notNull(),
  coverUrl: text("cover_url"),
  siteUrl: text("site_url").notNull(),
  genres: text("genres"),
  score: text("score"),
  status: text("status").notNull().default("planejo"),
  capitulo: text("capitulo"),
  addedAt: timestamp("added_at").notNull().defaultNow(),
});

export type ListaLeitura = typeof listaLeituraTable.$inferSelect;
export type InsertListaLeitura = typeof listaLeituraTable.$inferInsert;

// ─── Tabela: search_cache ─────────────────────────────────────────────────────
// Cache de resultados de busca por 24h para reduzir chamadas às APIs externas.

export const searchCache = pgTable("search_cache", {
  query: text("query").primaryKey(),
  results: json("results").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// ─── Tabela: title_aliases ────────────────────────────────────────────────────
// Mapeia títulos alternativos (aliases) para o título canônico de uma obra.

export const titleAliases = pgTable(
  "title_aliases",
  {
    id: serial("id").primaryKey(),
    canonicalTitle: text("canonical_title").notNull(),
    alias: text("alias").notNull(),
    source: text("source").notNull(),
  },
  (t) => [unique().on(t.canonicalTitle, t.alias)]
);

// ─── Tabela: description_matches ─────────────────────────────────────────────
// Aprendizado histórico: associa hashes de descrições a títulos encontrados.

// ─── Tabela: admin_users ──────────────────────────────────────────────────────
// Usuários do Discord com permissão de admin no bot.

export const adminUsersTable = pgTable("admin_users", {
  discordUserId: text("discord_user_id").primaryKey(),
  discordUsername: text("discord_username").notNull(),
  addedBy: text("added_by").notNull(),
  addedAt: timestamp("added_at").notNull().defaultNow(),
});

export type AdminUser = typeof adminUsersTable.$inferSelect;

// ─── Tabela: usage_logs ───────────────────────────────────────────────────────
// Registro de uso de comandos por usuários.

export const usageLogsTable = pgTable("usage_logs", {
  id: serial("id").primaryKey(),
  discordUserId: text("discord_user_id").notNull(),
  discordUsername: text("discord_username").notNull(),
  guildId: text("guild_id"),
  command: text("command").notNull(),
  query: text("query"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type UsageLog = typeof usageLogsTable.$inferSelect;

// ─── Tabela: web_admins ───────────────────────────────────────────────────────
// Contas de login do painel web administrativo.

export const webAdminsTable = pgTable("web_admins", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  name: text("name").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type WebAdmin = typeof webAdminsTable.$inferSelect;

// ─── Tabela: description_matches ─────────────────────────────────────────────

export const descriptionMatches = pgTable(
  "description_matches",
  {
    id: serial("id").primaryKey(),
    descriptionHash: text("description_hash").notNull(),
    descriptionSnippet: text("description_snippet"),
    canonicalTitle: text("canonical_title").notNull(),
    source: text("source").notNull(),
    similarityScore: real("similarity_score").notNull().default(0),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [unique().on(t.descriptionHash, t.canonicalTitle)]
);

export * from "./monitor";
